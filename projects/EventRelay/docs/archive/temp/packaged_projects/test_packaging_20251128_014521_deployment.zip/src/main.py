# Test Main
import asyncio

async def main():
    print('Hello EventRelay!')

if __name__ == '__main__':
    asyncio.run(main())
